function jobs_complete=JobsDoneInOneArrival(lambda, mu, x)
 
% Time until the next job arrives
next_arrival_time = exprnd(1/lambda);
t_completion_time = 0;
job_no = 0;
 
% Simulate job completions before the next arrival
while t_completion_time < next_arrival_time && job_no < x
job_no = job_no + 1;
completion_time = exprnd(1/mu);
t_completion_time = t_completion_time + completion_time;
end
 
 
jobs_complete = job_no - 1;
 
end
function [x2] =JobsDoneInTwoArrival(lambda, mu, x)
j1 = JobsDoneInOneArrival(lambda, mu, x);
x1 = (x - j1) + 1;
j2 = JobsDoneInOneArrival(lambda, mu, x1);
x2 = (x1 - j2) + 1;
end
% Part 1: x = 100, lambda = 1, mu = 10
x = 100;
lambda = 1;
mu = 10;
a = zeros(1, 10000);
for i = 1:10000
a(i) = JobsDoneInTwoArrival(lambda, mu, x);
end
figure(4);
histogram(a);
% Part 2: x = 3, lambda = 1, mu = 10
x = 3;
lambda = 1;
mu = 10;
b = zeros(1, 10000);
for i = 1:10000
b(i) = JobsDoneInTwoArrival(lambda, mu, x);
end
figure(5);
histogram(b);






