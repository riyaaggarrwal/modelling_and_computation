lambda=input("enter the value of lambda");
mu=input("enter the value of mu");
z=[]
function[t]=jobarr(lambda,mu)
time1=[];
time2=[];
y=[];
for i=1:100
    time1(i)=exprnd(1/mu);
    time2(i)=exprnd(1/lambda);
end
y(1) = time1(1);
for i=2:100
    y(i) = y(i-1)+time1(i);
end
for i=1:100
    if y(i)>=time2(i+1)
        t= i-1;
        break;
    end
end
end
for i=1:10000
    a=jobarr(lambda,mu);
    z=[z a];
end



histogram(z)
fprintf("mean number of jobs completed: %f",mean(z));
