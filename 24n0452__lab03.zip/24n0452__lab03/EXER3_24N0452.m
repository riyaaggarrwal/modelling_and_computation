lambda=input("enter the value of lambda");
n=input("enter the sample size");
T=input("enter the time");

exp(lamda,n,T)
function[Z] = exp(lamda,n,T)
     z = zeros(n, 1); 
    for j=1:n
        y=0;
        i=0;
        while y<T
            i =i +1;
            X(i)= exprnd(1/lam);
            y =y+ X(i);
        end
        
        % Z1 is the number of arrivals before time T
        z(j) = i - 1;
    end

   
    %plot histogram of andom sample
    figure;
    histogram(z)
    
end