l=input("enter the value of lambda");
mu=input("enter the value of mu");
x=input("enter the initial number of customers");
t=input("enter the value of total jobs");
k=input("enter the value of k")



function []=k_atm(l,mu,x,t)
b=[]
j=zeros(t,1)
X=zeros(t,1)
count=0
b(1)=0
for i=1:t
    if i==1
        j(1)=jobsdoneinonearrival(l,mu,x)
        X(1)=min(k,x-j(1)+1)
    else
        j(i)=jobsdoneinonearrival(l,mu,X(i-1))
        X(i)=min(k,X(i-1)-j(i)+1)
    end


end
if X(1)-j(1)>0
    b(2)=1
else
    b(2)=0
end
for i=3:t
    if x(i-2)-j(i)>0
        b(i)=b(i-1)+1
    else
        b(i)=b(i-1)

function[s]=jobsdoneinonearrival(l,mu,x)
t1=[] %service time of job;
t2=[] %arrival time of job;

for i=1:x
    t1(i)=exprnd(1/l);
    t2(i)=exprnd(1/mu);

end
y=[];
y(1)=t1(1);
for j=2:x
    y(j)=y(j-1)+t1(j);
end
s=0;
for i=1:x
    if y(i)>=t2(i+1)
        s=i-1;
        break;
    end


end 



end
